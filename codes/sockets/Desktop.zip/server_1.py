from socket import *
server = socket(AF_INET,SOCK_STREAM)
server.bind(("192.168.1.4",2020))
server.listen(50)
while(1):
    (cSock,cAddr) = server.accept()
    a = cSock.recv(10000)
    if a[-4:]==b'cl-1':
        b = a[:-4]
        cSock.send(bytes(str(b), 'UTF-8'))
    if a[-4:]==b'cl-2':
        b = a[:-4]
        cSock.send(bytes(str(b), 'UTF-8'))
    cSock.close()
    server.close()