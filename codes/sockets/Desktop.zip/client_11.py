from socket import *
while (1):
    i = (input()) + 'cl-2'
    mySock = socket(AF_INET,SOCK_STREAM)
    mySock.connect(("192.168.1.4",2020))
    mySock.send(bytes(str(i),'UTF-8'))
    print('server said:',mySock.recv(10000))
    mySock.close()